const todoListArr = [];

function addTodoList() {
  let found = false;
  if (document.getElementById("todoText").value.length < 1) {
    alert("It can't be blank!");
  } else {
    const todoText = document.getElementById("todoText").value;
    if (todoListArr.length > 0) {
      for (var i = 0; i < todoListArr.length; i++) {
        if (todoListArr[i].title.toUpperCase() == todoText.toUpperCase()) {
          found = true;
          break;
        }
      }
    }
    if (found) {
      alert("Duplicate todo task!");
    } else {
      todoListArr.push({
        title: todoText,
        check: false,
      });
      displayTodoList(todoListArr);
    }
  }
}

// text-decoration-line-throughs

function displayTodoList(todoListArr) {
  document.getElementById("todoList").innerHTML = "";
  const ul = document.getElementById("todoList");
  const li = document.createElement("li");
  li.innerHTML = "";
  for (var i = 0; i < todoListArr.length; i++) {
    if (todoListArr[i].check) {
      console.log(todoListArr[i].check);
      li.innerHTML +=
        `<li class="list-group-item d-flex justify-content-between align-items-center bg-info text-decoration-line-through">
                          <input class="form-check-input" id="check2" type="checkbox" checked onclick="strikeThisTodo(` +
        i +
        `)">` +
        todoListArr[i].title +
        `<button class="btn btn-danger" onclick="deleteThisTodo(` +
        i +
        `)">x</button>
                      </li>`;
    } else {
      li.innerHTML +=
        `<li class="list-group-item d-flex justify-content-between align-items-center">
                        <input class="form-check-input" id="check3" type="checkbox" onclick="strikeThisTodo(` +
        i +
        `)">` +
        todoListArr[i].title +
        `<button class="btn btn-danger" onclick="deleteThisTodo(` +
        i +
        `)">x</button>
                    </li>`;
    }
  }
  ul.appendChild(li);
}

function deleteThisTodo(index) {
  var result = confirm("Want to delete?");
  if (result) {
    todoListArr.splice(index, 1);
    displayTodoList(todoListArr);
  }
}

function strikeThisTodo(index) {
  if (todoListArr[index].check) {
    todoListArr[index].check = false;
  } else {
    todoListArr[index].check = true;
  }

  displayTodoList(todoListArr);
}

function showHideTodoList() {
  var ulBox = document.getElementById("todoList");
  if (ulBox.style.display === "none") {
    ulBox.style.display = "block";
  } else {
    ulBox.style.display = "none";
  }
}
